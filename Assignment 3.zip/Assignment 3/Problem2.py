# -*- coding: utf-8 -*-
"""
Created on Sun Oct 24 09:02:03 2021

@author: acer
"""

class PDF:
    
    filesize_threshold=1000
    def __init__(self, creator, flsize, date_taken, file_type, dimensions=0):
        self.creator=creator
        self.file_size=flsize
        self.date=date_taken
        self.dmn=dimensions
        self.file_type=file_type
        
    def discription(self):
        print("File type:", self.file_size)
        print("\nFile creator:",self.creator)
        print("\nDate of origin:",self.date)
        print("\nFile size in mb:",self.file_size)
        if self.dmn==0:
            pass
        else:
            print("\nFile dimensions",self.dmn)
        
        
    def isvalid(self):
        if self.file_size > PDF.filesize_threshold:
            print("Filze size exceeds the limit!")
        else:
            print("File size is valid ")
            
class Image(PDF):
    
    dimension_limit=1080*1080
    def __init__(self, creator, flsize, date_taken, file_type, dimensions=0):
        super().__init__( creator, flsize, date_taken, file_type, dimensions=0)
        
    def islimit(self):
        if self.dmn>=Image.dimension_limit:
            print("High dimensional")
        else:
            print("Dimensions within limit")
            
doc1 = PDF("Person1", 500, "19-07-2020", ".pdf")    
doc1.discription()
doc1.isvalid()
doc2 = Image('Person2', 600, "18-07-2020", ".jpeg", 1000*1000)
doc2.discription()
doc2.islimit()
            