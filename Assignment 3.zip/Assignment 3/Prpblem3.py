# -*- coding: utf-8 -*-
"""
Created on Sun Oct 24 13:22:07 2021

@author: acer
"""

class Vehicle:
    
   
    def __init__(self, name, mileage, capacity):
        self.name=name
        self.mileage=mileage
        self.capacity=capacity
        self.fare=self.capacity*100
    
    def amt(self):
        print(self.fare)
        
class Bus(Vehicle):
    
   def __init__(self, name, mileage, capacity):
        super().__init__(name, mileage, capacity)
        pass
    
   def amt(self):
        print(self.fare+self.fare*(0.1))
        

veh1=Vehicle('A',40,50)
veh2=Bus('A',40,50)
veh2.amt()
veh1.amt()
        
        
        
    
    