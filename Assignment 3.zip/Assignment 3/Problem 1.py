# -*- coding: utf-8 -*-
"""
Created on Sun Oct 24 08:38:44 2021

@author: acer
"""

class Student:
    def __init__(self, name, age, gender, rno, branch, sem):
        self.name=name
        self.rno=rno
        self.age=age
        self.gender=gender
        self.branch=branch
        self.sem=sem
        
    def basicinfo(self):
        print('Name:',self.name,'\n age:',self.age,'\n Gender:',self.gender,'\n Branch:',self.branch,'\n Sem:',self.sem,'\n Roll no:',self.rno)
        
        
class Result(Student):
    def __init__(self, name, age, gender, rno, branch, sem , marks, percentage):
        super().__init__(name, age, gender, rno, branch, sem)
        self.marks=marks
        self.percent=percentage
        
        
    def report(self):
        print('Marks obtained=',self.marks,'\n percentage=',self.percent)
        if self.percent>=90:
            print("Grade=A")
        if self.percent<90 and self.percent>=75:
            print("Grade=B")
        if self.percent<75 and self.percent>=60:
            print("Grade=C")
        if self.percent<60:
            print("Grade=Failed")
            
studrep=Result('Random', 16, 'Male', 44, "CS", 1, 545, 85)
studrep.basicinfo()
studrep.report()