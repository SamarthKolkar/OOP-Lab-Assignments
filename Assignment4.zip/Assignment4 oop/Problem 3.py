from queue import Queue

class Q:
    def __init__(self, max):
        self.max = max
        self.q = Queue(maxsize=self.max)

    def enq(self, data):
        self.q.put(data)

    def deq(self):
        print('Dequeued element ', self.q.get())

    def isempt(self):
        if self.q.empty():
            print("Queue is empty")
        else:
            print("Queue is not empty")

    def isful(self):
        if self.q.full():
            print("Queue is full")
        else:
            print("Queue is not full")

    def __del__(self):
        print("\ndeallocated")

ds= Q(5)
ds.enq(11)
ds.enq(10)
ds.enq(19)
ds.enq(15)
ds.deq()
ds.isempt()
ds.isful()

