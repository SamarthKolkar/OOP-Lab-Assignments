class rect:

    def __init__(self, length, breadth):
        self.len = length
        self.brd = breadth

    area = 0
    def areas(self):
        area=self.len * self.brd
        print(area)

rec1 = rect(10,20)
rec1.areas()


