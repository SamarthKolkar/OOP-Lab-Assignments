class Node:
    def __init__(self, data=None):
        self.data=data
        self.next=None

class Stack(Node):
    def __init__(self):
        super().__init__(data=None)
        self.head = None


    def stempty(self):
        if self.head is None:
            print("Stack is empty")
        else:
            print("Stack is not empty")

    def push(self,data):
        if self.head is None:
            self.head=Node(data)

        else:
            newnode = Node(data)
            temp = self.head
            while temp.next is not None:
                temp=temp.next
            temp.next=newnode

    def pop(self):
        if self.head is None:
            print("Stack Underflow")

        else:
            temp = self.head
            while temp.next.next is not None:
                temp=temp.next
            rem=temp.next
            temp.next=None
            rem=None

    def display(self):

        temp = self.head
        while temp is not None:
            print(temp.data)
            temp = temp.next


    def __del__(self):
        print('\n\nMemory deallocated')


stk=Stack()
#stk.stempty()
stk.push("Hello bozo")
stk.push("Hello world")
stk.push("my my")
stk.display()
stk.pop()
stk.display()
