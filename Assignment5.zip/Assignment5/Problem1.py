class shape:
    def __init__(self, length=0, breadth=0, radius=0):
        self.len = length
        self.brd = breadth
        self.rad=radius

    def area(self):
        A = self.brd * self.len
        print(A)

class square(shape):
    def __init__(self, side):
        super().__init__(side, side)

class rect(shape):
    def __init__(self, length, breadth):
        super().__init__(length, breadth)


class circle(shape):
    def __init__(self, radius):
        super().__init__(0, 0, radius)

    def area(self):
        A = 3.14*self.rad**2
        print(A)

sq = square(10)
rec = rect(10,20)
cir = circle(10)
sq.area()
rec.area()
cir.area()



