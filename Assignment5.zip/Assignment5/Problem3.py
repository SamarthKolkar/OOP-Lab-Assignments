class Car:
    def __init__(self, model_no):
        self.No=model_no

    def swap(self, other):
        self.No, other.No= other.No,self.No

    def diaplay(self):
        print(self.No)

car1=Car(1222)
car2=Car(1333)
car1.swap(car2)
car1.diaplay()
car2.diaplay()