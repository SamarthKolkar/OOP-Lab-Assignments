class Travel:
    head_count = 20
    def __init__(self, distance, mode=None):

        self.distance=distance
        self.mode=mode

    def cost(self, fare):
        return Travel.head_count * fare

class Train(Travel):

    cpp=60

    def __init__(self, d):
        super().__init__(d,'Train')

    def price(self):
        print("The cost of travelling from Dharwad to Belgavi through", self.mode," with headcount ",Travel.head_count, " will be", self.cost(Train.cpp), "Rupees")


class Bus(Travel):

    cpp=100

    def __init__(self, d):
        super().__init__(d,'Bus')

    def price(self):
        print("The cost of travelling from Dharwad to Belgavi through", self.mode," with headcount ",Travel.head_count, " will be", self.cost(Bus.cpp), "Rupees")

vehicle1=Train(70)
vehicle2=Bus(70)
vehicle2.price()
vehicle1.price()