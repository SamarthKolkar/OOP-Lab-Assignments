def late(list):
    arrived=len(list)
    fl=int(arrived/2)
    for attendee in list:
        if list.index(attendee)==arrived-1:
            print("\nNot fashionably late")
            continue
        if list.index(attendee)>=fl:
            print("\nfashionably late")
        else:
            print("\nNot fashionably late")


Arrivals=['Hardik', 'Rahul', 'Virat', 'Rishab', 'Mahi', 'Rohit', 'Rahane']
late(Arrivals)