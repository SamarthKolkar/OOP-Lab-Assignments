def pick(list , key):
    arti=[]
    for sentence in list:
        if key in sentence or key.capitalize() in sentence:
            arti.append(sentence)
    return arti


doc_list=["The Learn Python Challenge Rohit", "They bought a car", "banglore"]
word=input("Enter the keyword")
print("The filtered list of articles are ", pick(doc_list,word))