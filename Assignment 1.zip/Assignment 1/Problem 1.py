def leap(year):
    if year%4 == 0:
        return True
    else:
        return False


y=int(input("Enter the year to know wheather it's a leap year or not"))
if leap(y):
    print("\nleap year")
else:
    print("\nNot leap year")