def isweird(n):
    if n == 1 or n%2 == 1:
        print("wierd")
    elif n%2==0 and n>=2 and n<=5:
        print("not weird")
    elif n%2==0 and n>=6 and n<=20:
        print("weird")
    elif n%2==0 and n>=20:
        print("not weird")

number=int(input("Enter a number"))
isweird(number)