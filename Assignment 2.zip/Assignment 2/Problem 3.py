
class Account:
    def __init__(self, name, acc_no, amount):
        self.name=name
        self.acno=acc_no
        self.amt=amount

    
    def accdetails(self):
        return self.name,self.acno,self.amt
        
    def deposit(self, add):
        self.amt=self.amt+add
        
    def withdraw(self, sub):
        self.amt=self.amt-sub
        
    def accbal(self):
        return self.amt
    

cust=Account('X', 1234, 1000000)
print(cust.accdetails())
cust.deposit(20000)
cust.withdraw(5000)
print(cust.accbal())