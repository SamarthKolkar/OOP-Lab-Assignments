

class Faculty:
    def __init__(self, name, empid, branch, salary):
        self.name=name
        self.e_id=empid
        self.branch=branch
        self.salary=salary
        
    def getname(self):
        return self.name
    
    def geteid(self):
        return self.e_id
    
    def getbranch(self):
        return self.branch
    
    def getsal(self):
        return self.salary
    
    
    
fac1 = Faculty('A', 'ab12', 'CS', 50000)
fac2 = Faculty('B', 'ab13', 'DS', 50000)
fac3 = Faculty('C', 'ab14', 'HS', 50000)
fac4 = Faculty('D', 'ab15', 'EC', 50000)
fac5 = Faculty('E', 'ab16', 'IT', 50000)

faclist=[fac1, fac2, fac3, fac4, fac5]

for teach in faclist:
    print('Name:',teach.getname(),'\n')
    print('EMP ID:',teach.geteid(),'\n')
    print('Branch:',teach.getbranch(),'\n')
    print('Salary:',teach.getsal(),'\n\n\n')