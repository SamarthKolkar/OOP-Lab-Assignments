class Circle:
    def __init__(self, radius):
        self.rad=radius

    def area(self):
        return self.rad**2 *3.14

    def peri(self):
        return 2*3.14*self.rad

curve = Circle(10)
a=curve.area()
p=curve.peri()
print(a, " ",p)