class student:
    def __init__(self, name, rno, age):
        self.name=name
        self.rno=rno
        self.age=age

    def cmp(self, other):
        if self.age == other.age:
            print("Students are of same age")
        else:
            print("Not same age")

stud1 = student('Rahul',21, 33)
stud2 = student('Rahul',22, 73)
stud1.cmp(stud2)