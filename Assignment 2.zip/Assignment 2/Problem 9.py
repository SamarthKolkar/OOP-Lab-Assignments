class student:
    def __init__(self, name, rno, age):
        self.name=name
        self.rno=rno
        self.age=age
        self.lp1 = self.laptop("x86", 8, 800)
        self.lp2 = self.laptop("ARM", 8, 883)
        self.lp3 = self.laptop("AMD", 16, 1000)


    def display(self):
        print(self.name, self.rno, self.age)


    class laptop:
        def __init__(self, cpu, ram, hrdisk):
            self.cpu=cpu
            self.ram=ram
            self.hrd=hrdisk

        def specs(self):
            print(self.cpu, self.ram, self.hrd)

stud=student("A", 50, 19)
"""lp1 = student.laptop("x86", 8, 800)
lp2 = student.laptop("ARM", 8, 883)
lp3 = student.laptop("AMD", 16, 1000)"""
stud.display()
stud.lp1.specs()