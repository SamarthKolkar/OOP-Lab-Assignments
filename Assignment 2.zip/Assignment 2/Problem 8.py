class student:

    institue_name= "IIITD"
    sem='IIIrd'

    def __init__(self, name, usn):
        self.name=name
        self.usn=usn

    def display_inst(self):
        print(self.name,self.usn)

    @classmethod
    def display_class(cls):
        print(student.institue_name, student.sem)

    @staticmethod
    def descrip():
        print("The class called student contains both class and instance variables and methods, as well as static method")

stud = student("A", 100)
stud.display_class()
stud.display_inst()
student.descrip()