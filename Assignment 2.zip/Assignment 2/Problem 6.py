class Time:
    def __init__(self):
        self.hours = 0
        self.mins = 0
        self.secs = 0

    def inst(self, hrs, min, sec):
        self.hours = hrs
        self.mins = min
        self.secs = sec

    def display(self):
        print(self.hours,':',self.mins,':',self.secs)

instant=Time()
instant.inst(23,15,45)
instant.display()